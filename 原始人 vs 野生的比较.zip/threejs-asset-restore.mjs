import { createHash, randomUUID } from 'node:crypto'
import { createReadStream, existsSync, lstatSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { open } from 'node:fs/promises'
import { setTimeout as delay } from 'node:timers/promises'
import { HYDRATION_TIMEOUT_MS, RESTORE_WORKERS, RESTORE_MAX_ATTEMPTS, transientDownloadError } from './asset-restore-policy.mjs'
import { dirname, join } from 'node:path'
import { assetTypeOf, directAssetUrl, isSafeAssetRel, MAX_ASSET_SIZE_BYTES, projectStorageKey, readAssetsManifest } from './local-artifacts.mjs'
import { storageConfig, storageURL } from './storage.mjs'
import { installAssetFile } from './install-asset.mjs'

export function threejsAssetEntries(root, { trustExisting = false } = {}) {
  const file = join(root, 'assets.lock.json')
  if (!existsSync(file)) return []
  const info = lstatSync(file)
  if (!info.isFile() || info.isSymbolicLink() || info.size > 1024 * 1024) throw new Error('Invalid asset manifest')
  const entries = Object.entries(readAssetsManifest(root).assets)
  for (const [rel, entry] of entries) {
    if (trustExisting && isSafeAssetRel(root, rel) && existsSync(join(root, rel))) continue
    if (!isSafeAssetRel(root, rel) || /[\u0000-\u001f%?#:]/u.test(rel) || !assetTypeOf(rel) ||
        !/^sha256:[a-f0-9]{64}$/.test(entry.sha256) || !Number.isSafeInteger(entry.size) || entry.size <= 0 || entry.size > MAX_ASSET_SIZE_BYTES) {
      throw new Error('Asset manifest requires safe paths and exact size/hash pins')
    }
  }
  return entries
}

const recovery = {
  asset_changed: 'The file changed during checkpoint restoration. Preserve ongoing edits, stop editing, then retry.',
  manifest_changed: 'The asset manifest changed during restoration. Stop editing and restore the intended checkpoint before retrying.',
  storage_configuration: 'Activate the project runtime with a complete Storage configuration and retry.',
  authorization: 'Refresh project Storage authorization and retry.',
  not_found: 'Restore the missing object in project Storage or select a checkpoint with an available asset.',
  size_mismatch: 'The download does not match the saved size. Retry or repair the stored asset; local edits were preserved.',
  hash_mismatch: 'The download does not match the saved hash. Retry or repair the stored asset; local edits were preserved.',
  download_failed: 'Retry when Storage is available. Local edits were preserved.',
  unsafe_path: 'Use regular project files and safe relative asset paths.',
}
export class ThreejsAssetRestoreError extends Error {
  constructor(code, asset, status) {
    const safeCode = Object.hasOwn(recovery, code) ? code : 'download_failed'
    super(`Cannot restore the saved asset version: ${safeCode}`)
    this.code = safeCode
    this.asset = asset
    if (Number.isInteger(status) && status >= 100 && status <= 599) this.status = status
  }
}
export function assetRestoreDiagnostic(error) {
  const known = error instanceof ThreejsAssetRestoreError
  const code = known ? error.code : 'download_failed'
  return { code, ...(known && error.asset ? { asset: error.asset } : {}),
    ...(known && error.status ? { httpStatus: error.status } : {}), recovery: recovery[code] }
}
function restoreError(error, rel) {
  const status = error?.status
  const code = error instanceof ThreejsAssetRestoreError ? error.code
    : [401, 403].includes(status) ? 'authorization' : status === 404 ? 'not_found'
    : ['storage_not_configured', 'storage_configuration_conflict', 'storage_invalid_endpoint'].includes(error?.code) ? 'storage_configuration' : 'download_failed'
  return new ThreejsAssetRestoreError(code, rel, status)
}
export async function assetFingerprint(file) {
  const hash = createHash('sha256')
  let size = 0
  for await (const chunk of createReadStream(file)) { size += chunk.length; hash.update(chunk) }
  return { size, sha256: 'sha256:' + hash.digest('hex') }
}
export async function verifyThreejsAsset(file, entry) {
  const actual = await assetFingerprint(file)
  if (actual.size !== entry.size) throw new ThreejsAssetRestoreError('size_mismatch')
  if (actual.sha256 !== entry.sha256) throw new ThreejsAssetRestoreError('hash_mismatch')
}

async function downloadAsset(entry, temporary, signal) {
  let url = directAssetUrl(entry)
  if (!url) {
    const key = projectStorageKey(entry.path)
    if (!key) throw new Error('Invalid asset storage path')
    const config = storageConfig()
    const endpoint = new URL('v1/storage/presign/get', config.url + '/')
    endpoint.searchParams.set('path', key)
    const response = await fetch(endpoint, { headers: { Authorization: `Bearer ${config.key}` }, redirect: 'error', signal })
    if (!response.ok) { await response.body?.cancel(); throw Object.assign(new Error('Asset download authorization failed'), { status: response.status }) }
    // Signed URLs exist only for this download, never in project source or the lock.
    url = (await response.json()).url
  }
  const response = await fetch(storageURL(url), { redirect: 'error', credentials: 'omit', signal })
  if (!response.ok || !response.body) { await response.body?.cancel(); throw Object.assign(new Error('Asset download failed'), { status: response.status }) }
  const reader = response.body.getReader()
  const file = await open(temporary, 'w')
  let size = 0
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      size += value.byteLength
      if (size > entry.size) throw new ThreejsAssetRestoreError('size_mismatch')
      await file.writeFile(value)
    }
  } finally { await file.close(); await reader.cancel().catch(() => {}); reader.releaseLock() }
  if (size !== entry.size) throw new ThreejsAssetRestoreError('size_mismatch')
}

/** Normal builds only fill missing files. Explicit checkpoint restoration also replaces
 * existing bytes from the selected lock. Neither mode uploads or rewrites the lock. */
export async function restoreThreejsAssets(root, { signal, readAsset, includeAsset = () => true, mode = 'build' } = {}) {
  const controller = new AbortController()
  const deadline = AbortSignal.any([AbortSignal.timeout(HYDRATION_TIMEOUT_MS), controller.signal, ...(signal ? [signal] : [])])
  const entries = threejsAssetEntries(root, { trustExisting: mode === 'snapshot' }).filter(([rel]) => includeAsset(rel))
  const manifestFile = join(root, 'assets.lock.json')
  const frozenManifest = mode === 'checkpoint' && entries.length ? readFileSync(manifestFile) : undefined
  let restored = 0, next = 0
  const worker = async () => {
    let asset
    try {
      while (next < entries.length) {
        deadline.throwIfAborted()
        const [rel, entry] = entries[next++]
        asset = rel
        const target = join(root, rel)
        let original
        if (existsSync(target)) {
          if (mode !== 'checkpoint') continue
          original = await assetFingerprint(target)
          if (original.size === entry.size && original.sha256 === entry.sha256) continue
        }
        if (!isSafeAssetRel(root, rel)) throw new Error('Unsafe asset destination')
        mkdirSync(dirname(target), { recursive: true })
        const temporary = target + '.' + randomUUID() + '.tmp'
        try {
          writeFileSync(temporary, '', { flag: 'wx' })
          if (readAsset) {
            // The authorized history reader already retries and returns bounded bytes.
            const bytes = await readAsset(rel, entry, deadline)
            if (!bytes || bytes.byteLength !== entry.size) throw new ThreejsAssetRestoreError('size_mismatch')
            writeFileSync(temporary, bytes)
          } else {
            for (let attempt = 1; ; attempt++) {
              try { await downloadAsset(entry, temporary, deadline); break }
              catch (error) {
                deadline.throwIfAborted()
                if (attempt >= RESTORE_MAX_ATTEMPTS || !transientDownloadError(error)) throw error
                await delay(250 * attempt, undefined, { signal: deadline })
              }
            }
          }
          deadline.throwIfAborted()
          await verifyThreejsAsset(temporary, entry)
          if (!isSafeAssetRel(root, rel)) throw new Error('Unsafe asset destination')
          try {
            if (frozenManifest && !readFileSync(manifestFile).equals(frozenManifest)) throw new ThreejsAssetRestoreError('manifest_changed')
            if (original) {
              // The explicit rollback authorizes replacement, but never install
              // over an edit that arrived while the selected bytes downloaded.
              try { await verifyThreejsAsset(target, original) }
              catch { throw new ThreejsAssetRestoreError('asset_changed') }
              if (!isSafeAssetRel(root, rel)) throw new ThreejsAssetRestoreError('unsafe_path')
              if (!readFileSync(manifestFile).equals(frozenManifest)) throw new ThreejsAssetRestoreError('manifest_changed')
              deadline.throwIfAborted()
              renameSync(temporary, target)
            } else await installAssetFile(temporary, target, deadline)
            restored++
          }
          catch (error) {
            if (original || error.code !== 'EEXIST' || !isSafeAssetRel(root, rel)) throw error
            await verifyThreejsAsset(target, entry)
          }
        } finally { rmSync(temporary, { force: true }) }
      }
    } catch (error) { controller.abort(restoreError(error, asset)) }
  }
  // Direct downloads stream to disk. Keep buffer-returning history reads serial.
  await Promise.all(Array.from({ length: Math.min(readAsset ? 1 : RESTORE_WORKERS, entries.length) }, worker))
  deadline.throwIfAborted()
  return restored
}
