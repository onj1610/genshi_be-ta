import fs from 'node:fs/promises'
import path from 'node:path'
import { readAssetsManifest } from './local-artifacts.mjs'

/** Select explicit paths and conservatively include directories named by dynamic references.
 * CDN references stay remote. The lock and generated restore scripts are not game dependencies. */
export async function referencedLocalAssets(root) {
  const assets = new Set(Object.keys(readAssetsManifest(root).assets)), used = new Set()
  if (!assets.size) return used
  const visit = async (directory) => {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name), relative = path.relative(root, file).split(path.sep).join('/')
      if (['.git', '.manus-webdev', 'node_modules', 'dist'].includes(entry.name) || relative === 'scripts/manus-game-assets') continue
      if (entry.isDirectory()) { await visit(file); continue }
      if (!entry.isFile() || ['assets.lock.json', 'package-lock.json'].includes(entry.name) || !/\.(?:[cm]?[jt]sx?|json|html|css|scss|sass|svg|glsl|wgsl)$/iu.test(entry.name)) continue
      const text = (await fs.readFile(file, 'utf8')).replace(/\\(?:\/|u002f|x2f)/giu, '/')
      for (const match of text.matchAll(/"([^"\r\n]*)"|'([^'\r\n]*)'|`([^`]*)`|\burl\(\s*([^"'()\s]+)\s*\)/gu)) {
        const value = (match[1] ?? match[2] ?? match[3] ?? match[4]).split(/[?#]/u)[0]
        if (!value || /^(?:[a-z]+:|\/\/|\/manus-storage\/)/iu.test(value)) continue
        const projectPath = value.replace(/^\//u, '')
        const candidates = [path.resolve(path.dirname(file), value), path.resolve(root, projectPath), path.resolve(root, 'public', projectPath)]
        for (const candidate of candidates) {
          const asset = path.relative(root, candidate).split(path.sep).join('/')
          if (assets.has(asset)) { used.add(asset); continue }
          // Glob/template/concatenated directory references may select files only
          // after hydration. Keep the whole named directory (including textures),
          // not the entire library; this intentionally over-includes glob exclusions.
          const dynamic = asset.search(/\$\{|[*{[]/u)
          const prefix = dynamic < 0 ? asset : asset.slice(0, dynamic)
          const directory = dynamic < 0 && value.endsWith('/')
            ? asset + '/'
            : dynamic >= 0 ? prefix.slice(0, prefix.lastIndexOf('/') + 1) : ''
          if (directory) for (const registered of assets) {
            if (registered.startsWith(directory)) used.add(registered)
          }
        }
      }
    }
  }
  await visit(root)
  return used
}
